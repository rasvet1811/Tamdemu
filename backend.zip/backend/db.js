// db.js
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: 'localhost',       // o la dirección de tu servidor MySQL
  user: 'root',      // tu usuario de MySQL
  password: 'root123*', // tu contraseña
  database: 'tandemu_db',  // el nombre de tu base de datos
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = pool;