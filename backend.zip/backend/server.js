// =============================================
// Configuración Inicial y Variables Globales
// =============================================
const API_BASE_URL = 'http://localhost:5000/api';
let currentUser = null;

// =============================================
// Funciones de Autenticación
// =============================================

async function registerUser(name, email, password, role) {
  try {
    const response = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password, role })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Error en el registro');
    }
    
    localStorage.setItem('token', data.token);
    currentUser = await getCurrentUser(data.token);
    return { success: true, user: currentUser };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function loginUser(email, password) {
  try {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Credenciales inválidas');
    }
    
    localStorage.setItem('token', data.token);
    currentUser = await getCurrentUser(data.token);
    return { success: true, user: currentUser };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function getCurrentUser(token) {
  try {
    const response = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Error obteniendo usuario');
    }
    
    return data.data;
  } catch (error) {
    console.error('Error:', error);
    return null;
  }
}

function logoutUser() {
  localStorage.removeItem('token');
  currentUser = null;
  window.location.href = 'login.html';
}

// =============================================
// Funciones de Usuarios
// =============================================

async function updateUserProfile(userId, updates) {
  try {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/users/${userId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(updates)
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Error actualizando perfil');
    }
    
    currentUser = data.data;
    return { success: true, user: currentUser };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// =============================================
// Funciones de Archivos
// =============================================

async function uploadFile(file, subject) {
  try {
    const token = localStorage.getItem('token');
    const formData = new FormData();
    formData.append('file', file);
    formData.append('subject', subject);
    
    const response = await fetch(`${API_BASE_URL}/files`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Error subiendo archivo');
    }
    
    return { success: true, file: data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function getFilesBySubject(subject) {
  try {
    const response = await fetch(`${API_BASE_URL}/files/${subject}`);
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Error obteniendo archivos');
    }
    
    return { success: true, files: data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// =============================================
// Funciones de Asesorías
// =============================================

async function getAdvisories() {
  try {
    const response = await fetch(`${API_BASE_URL}/advisories`);
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Error obteniendo asesorías');
    }
    
    return { success: true, advisories: data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function bookAdvisory(advisoryId, scheduleId) {
  try {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/advisories/book`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ advisoryId, scheduleId })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Error agendando asesoría');
    }
    
    return { success: true, booking: data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// =============================================
// Funciones de PQR
// =============================================

async function createPQR(type, subject, description) {
  try {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/pqrs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ type, subject, description })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Error creando PQR');
    }
    
    return { success: true, pqr: data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function getUserPQRs() {
  try {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/pqrs/user`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Error obteniendo PQRs');
    }
    
    return { success: true, pqrs: data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// =============================================
// Funciones de la Interfaz - Navegación
// =============================================

function mostrarSeccion(id) {
  const secciones = document.querySelectorAll("main section");
  secciones.forEach(seccion => seccion.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  
  // Cargar datos específicos de la sección
  switch(id) {
    case 'inicio':
      cargarPublicaciones();
      break;
    case 'asesorias':
      cargarAsesorias();
      break;
    case 'materias':
      cargarMaterias();
      break;
    case 'pqr':
      cargarPQRs();
      break;
    case 'perfil':
      cargarPerfil();
      break;
  }
}

function cerrarSesion() {
  logoutUser();
}

// =============================================
// Funciones de la Interfaz - Asesorías
// =============================================

async function cargarAsesorias() {
  const result = await getAdvisories();
  
  if (result.success) {
    const container = document.querySelector('#asesorias .asesores');
    container.innerHTML = '';
    
    result.advisories.forEach(advisor => {
      const advisorElement = document.createElement('div');
      advisorElement.className = 'asesor';
      advisorElement.innerHTML = `
        <h3>${advisor.title}</h3>
        <p>Carrera: ${advisor.subject}</p>
        <p>${advisor.description}</p>
        <button onclick="mostrarCalendario('${advisor._id}', '${advisor.title}')">Agendar Asesoría</button>
        <button onclick="iniciarChat('${advisor.advisor._id}', '${advisor.advisor.name}')">Contactar</button>
      `;
      container.appendChild(advisorElement);
    });
  } else {
    alert(result.error);
  }
}

function mostrarCalendario(advisoryId, advisoryTitle) {
  document.getElementById('asesorNombre').textContent = advisoryTitle;
  document.getElementById('cursoNombre').textContent = advisoryTitle;
  document.getElementById('calendarModal').style.display = 'block';
  
  // Aquí deberías cargar las fechas disponibles para esta asesoría
  document.getElementById('calendarPicker').innerHTML = `
    <p>Selecciona una fecha disponible:</p>
    <input type="date" id="fechaAsesoria" style="padding: 8px; width: 100%;">
    <p>Hora: <select id="horaAsesoria" style="padding: 8px; width: 100%;">
      <option>09:00 AM</option>
      <option>10:00 AM</option>
      <option>11:00 AM</option>
      <option>02:00 PM</option>
      <option>03:00 PM</option>
      <option>04:00 PM</option>
    </select></p>
  `;
}

async function confirmarAgendamiento() {
  const fecha = document.getElementById('fechaAsesoria').value;
  const hora = document.getElementById('horaAsesoria').value;
  
  if (!fecha) {
    alert('Por favor selecciona una fecha');
    return;
  }
  
  const advisoryTitle = document.getElementById('asesorNombre').textContent;
  
  // En una implementación real, aquí enviarías los datos al backend
  const result = await bookAdvisory('advisory_id_placeholder', 'schedule_id_placeholder');
  
  if (result.success) {
    alert(`Asesoría agendada correctamente:\n\nAsesor: ${advisoryTitle}\nFecha: ${fecha}\nHora: ${hora}`);
    cerrarModal();
  } else {
    alert(result.error);
  }
}

function iniciarChat(userId, userName) {
  document.getElementById('chatAsesor').textContent = userName;
  document.getElementById('chatBox').innerHTML = `
    <p><strong>${userName}:</strong> Hola, ¿en qué puedo ayudarte?</p>
  `;
  document.getElementById('chatModal').style.display = 'block';
}

function enviarMensaje() {
  const input = document.getElementById('mensajeInput');
  const mensaje = input.value.trim();
  const asesor = document.getElementById('chatAsesor').textContent;
  
  if (mensaje) {
    const chatBox = document.getElementById('chatBox');
    chatBox.innerHTML += `<p><strong>Tú:</strong> ${mensaje}</p>`;
    input.value = '';
    
    // Simular respuesta después de 1 segundo
    setTimeout(() => {
      chatBox.innerHTML += `<p><strong>${asesor}:</strong> Recibí tu mensaje. Te responderé pronto.</p>`;
      chatBox.scrollTop = chatBox.scrollHeight;
    }, 1000);
    
    chatBox.scrollTop = chatBox.scrollHeight;
  }
}

function cerrarModal() {
  document.getElementById('calendarModal').style.display = 'none';
  document.getElementById('chatModal').style.display = 'none';
}

// =============================================
// Funciones de la Interfaz - Materias
// =============================================

async function cargarMaterias() {
  // Ejemplo con algunas materias estáticas
  const materias = ['Matemáticas', 'Programación', 'Física', 'Inglés'];
  const container = document.querySelector('.materias-grid');
  container.innerHTML = '';
  
  materias.forEach(materia => {
    const materiaElement = document.createElement('div');
    materiaElement.className = 'materia-card';
    materiaElement.innerHTML = `
      <div class="materia-icon">📚</div>
      <div class="materia-title">${materia}</div>
      <div class="materia-count">${Math.floor(Math.random() * 10) + 1} archivos</div>
    `;
    materiaElement.onclick = () => mostrarContenidos(materia.toLowerCase());
    container.appendChild(materiaElement);
  });
}

function mostrarContenidos(materiaId) {
  // Ocultar todos los contenidos primero
  document.querySelectorAll('.file-info').forEach(el => {
    el.classList.remove('active');
  });
  
  // Mostrar el contenido seleccionado
  const selectedContent = document.getElementById(materiaId);
  if (selectedContent) {
    selectedContent.classList.add('active');
  }
  
  // Cargar archivos de esta materia
  cargarArchivosMateria(materiaId);
}

async function cargarArchivosMateria(materia) {
  const result = await getFilesBySubject(materia);
  
  if (result.success) {
    const container = document.querySelector(`#${materia} .file-list`);
    if (container) {
      container.innerHTML = '<h4>Archivos disponibles:</h4>';
      
      result.files.forEach(file => {
        const fileElement = document.createElement('div');
        fileElement.className = 'file-item';
        fileElement.innerHTML = `
          <span>📄</span>
          <span class="file-name">${file.name}</span>
          <a href="#" onclick="descargarArchivo('${file._id}')" class="file-download">Descargar</a>
        `;
        container.appendChild(fileElement);
      });
    }
  }
}

async function subirContenido(materia) {
  const fileInput = document.getElementById(`${materia.toLowerCase()}File`);
  
  if (fileInput.files.length === 0) {
    alert('Por favor selecciona un archivo');
    return;
  }
  
  const result = await uploadFile(fileInput.files[0], materia);
  
  if (result.success) {
    alert(`Archivo "${fileInput.files[0].name}" subido correctamente a ${materia}`);
    fileInput.value = '';
    cargarArchivosMateria(materia);
  } else {
    alert(result.error);
  }
}

async function descargarArchivo(fileId) {
  // En una implementación real, redirigiría al endpoint de descarga
  window.open(`${API_BASE_URL}/files/download/${fileId}`, '_blank');
}

// =============================================
// Funciones de la Interfaz - PQR
// =============================================

async function cargarPQRs() {
  if (!currentUser) return;
  
  const result = await getUserPQRs();
  
  if (result.success) {
    const container = document.querySelector('.pqr-container');
    container.innerHTML = '';
    
    // Agregar preguntas frecuentes
    container.innerHTML = `
      <div class="pqr-card">
        <div class="pqr-category">Horarios</div>
        <div class="pqr-item">
          <div class="pqr-question">1: ¿Cuáles son los horarios de atención?</div>
          <div class="pqr-answer">Lunes a viernes de 8:00 am a 6:00 pm, sábados de 9:00 am a 1:00 pm.</div>
        </div>
      </div>
      
      <div class="pqr-card">
        <div class="pqr-category">Asesorías</div>
        <div class="pqr-item">
          <div class="pqr-question">1: ¿Cómo agendo una asesoría?</div>
          <div class="pqr-answer">Puedes agendarla directamente en la sección de Asesorías.</div>
        </div>
      </div>
      
      <div class="pqr-form-container">
        <h3 class="pqr-form-title">¿No encontraste lo que buscabas?</h3>
        <form onsubmit="enviarPQR(event)">
          <label for="pqrTipo">Tipo de solicitud:</label>
          <select id="pqrTipo" required>
            <option value="">Selecciona...</option>
            <option value="peticion">Petición</option>
            <option value="queja">Queja</option>
            <option value="reclamo">Reclamo</option>
          </select>
          
          <label for="pqrAsunto">Asunto:</label>
          <input type="text" id="pqrAsunto" required>
          
          <label for="pqrDescripcion">Descripción:</label>
          <textarea id="pqrDescripcion" rows="4" required></textarea>
          
          <button type="submit">Enviar solicitud</button>
        </form>
      </div>
    `;
    
    // Mostrar PQRs del usuario si existen
    if (result.pqrs.length > 0) {
      const pqrSection = document.createElement('div');
      pqrSection.className = 'pqr-card';
      pqrSection.innerHTML = '<div class="pqr-category">Mis Solicitudes</div>';
      
      result.pqrs.forEach(pqr => {
        pqrSection.innerHTML += `
          <div class="pqr-item">
            <div class="pqr-question">${pqr.type.toUpperCase()}: ${pqr.subject}</div>
            <div class="pqr-answer">${pqr.description}</div>
            <div class="pqr-status">Estado: ${pqr.status}</div>
          </div>
        `;
      });
      
      container.insertBefore(pqrSection, container.querySelector('.pqr-form-container'));
    }
  } else {
    alert(result.error);
  }
}

async function enviarPQR(event) {
  event.preventDefault();
  
  const tipo = document.getElementById('pqrTipo').value;
  const asunto = document.getElementById('pqrAsunto').value;
  const descripcion = document.getElementById('pqrDescripcion').value;
  
  const result = await createPQR(tipo, asunto, descripcion);
  
  if (result.success) {
    alert('Tu solicitud PQR ha sido enviada correctamente.');
    document.getElementById('pqrForm').reset();
    cargarPQRs();
  } else {
    alert(result.error);
  }
}

// =============================================
// Funciones de la Interfaz - Perfil
// =============================================

function cargarPerfil() {
  if (!currentUser) return;
  
  document.getElementById('fotoPerfil').src = currentUser.avatar || 'img/avatar-default.png';
  document.querySelector('.perfil-header h2').textContent = currentUser.name;
  document.querySelector('.perfil-header p').textContent = `Estudiante de ${currentUser.career || 'Ingeniería'}`;
  
  document.querySelector('.perfil-info').innerHTML = `
    <p><strong>Fecha de registro:</strong> ${new Date(currentUser.createdAt).toLocaleDateString()}</p>
    <p><strong>Universidad:</strong> IUSH</p>
    <p><strong>Correo electrónico:</strong> ${currentUser.email}</p>
  `;
}

function editarPerfil() {
  // Implementación básica - en una app real abriría un formulario de edición
  const nuevoNombre = prompt('Ingresa tu nuevo nombre:', currentUser.name);
  if (nuevoNombre && nuevoNombre !== currentUser.name) {
    updateUserProfile(currentUser._id, { name: nuevoNombre })
      .then(result => {
        if (result.success) {
          cargarPerfil();
          alert('Perfil actualizado correctamente');
        } else {
          alert(result.error);
        }
      });
  }
}

// =============================================
// Funciones de la Interfaz - Inicio/Publicaciones
// =============================================

async function cargarPublicaciones() {
  // En una implementación real, esto vendría de una API
  const publicaciones = [
    {
      id: 1,
      titulo: "Convocatoria para monitorías",
      descripcion: "Se abren convocatorias para monitorías en el departamento de matemáticas.",
      imagen: "https://source.unsplash.com/random/600x400/?university",
      autor: { nombre: "Departamento de Matemáticas", avatar: "https://randomuser.me/api/portraits/women/44.jpg" },
      likes: 12,
      comentarios: 3
    },
    {
      id: 2,
      titulo: "Cambio de horario tutorías",
      descripcion: "A partir de la próxima semana, las tutorías de física cambiarán de horario.",
      autor: { nombre: "Prof. Carlos López", avatar: "https://randomuser.me/api/portraits/men/32.jpg" },
      likes: 8,
      comentarios: 1
    }
  ];
  
  const container = document.querySelector('.publicaciones-container');
  container.innerHTML = '';
  
  publicaciones.forEach(publicacion => {
    const pubElement = document.createElement('div');
    pubElement.className = 'publicacion-card';
    
    let imagenHTML = '';
    if (publicacion.imagen) {
      imagenHTML = `<img src="${publicacion.imagen}" alt="Publicación" class="publicacion-imagen">`;
    }
    
    pubElement.innerHTML = `
      ${imagenHTML}
      <div class="publicacion-contenido">
        <h3 class="publicacion-titulo">${publicacion.titulo}</h3>
        <p class="publicacion-descripcion">${publicacion.descripcion}</p>
        <div class="publicacion-meta">
          <div class="publicacion-autor">
            <img src="${publicacion.autor.avatar}" alt="Autor" class="autor-avatar">
            <span>${publicacion.autor.nombre}</span>
          </div>
          <div class="publicacion-acciones">
            <button class="accion-btn">👍 ${publicacion.likes}</button>
            <button class="accion-btn">💬 ${publicacion.comentarios}</button>
          </div>
        </div>
      </div>
    `;
    
    container.appendChild(pubElement);
  });
}

function publicar() {
  const texto = document.querySelector('#inicio textarea').value.trim();
  
  if (!texto) {
    alert('Por favor escribe algo para publicar');
    return;
  }
  
  // En una implementación real, aquí enviarías la publicación al backend
  const container = document.querySelector('.publicaciones-container');
  const nuevaPublicacion = document.createElement('div');
  nuevaPublicacion.className = 'publicacion-card';
  nuevaPublicacion.innerHTML = `
    <div class="publicacion-contenido">
      <h3 class="publicacion-titulo">Nueva publicación</h3>
      <p class="publicacion-descripcion">${texto}</p>
      <div class="publicacion-meta">
        <div class="publicacion-autor">
          <img src="${currentUser.avatar || 'https://randomuser.me/api/portraits/men/1.jpg'}" alt="Autor" class="autor-avatar">
          <span>Tú</span>
        </div>
        <div class="publicacion-acciones">
          <button class="accion-btn">👍 0</button>
          <button class="accion-btn">💬 0</button>
        </div>
      </div>
    </div>
  `;
  
  container.insertBefore(nuevaPublicacion, container.firstChild);
  document.querySelector('#inicio textarea').value = '';
  alert('Tu publicación ha sido compartida');
}

// =============================================
// Inicialización de la Aplicación
// =============================================

document.addEventListener('DOMContentLoaded', function() {
  // Verificar autenticación al cargar
  const token = localStorage.getItem('token');
  if (token) {
    getCurrentUser(token).then(user => {
      currentUser = user;
      // Mostrar sección activa basada en hash de URL
      const hash = window.location.hash.substring(1) || 'inicio';
      mostrarSeccion(hash);
    });
  } else if (!window.location.pathname.endsWith('login.html')) {
    window.location.href = 'login.html';
  }
  
  // Configurar eventos globales
  window.onclick = function(event) {
    if (event.target.className === 'modal') {
      cerrarModal();
    }
  };
});

// =============================================
// Exponer funciones al ámbito global
// =============================================
window.mostrarSeccion = mostrarSeccion;
window.cerrarSesion = cerrarSesion;
window.mostrarCalendario = mostrarCalendario;
window.confirmarAgendamiento = confirmarAgendamiento;
window.iniciarChat = iniciarChat;
window.enviarMensaje = enviarMensaje;
window.cerrarModal = cerrarModal;
window.mostrarContenidos = mostrarContenidos;
window.subirContenido = subirContenido;
window.descargarArchivo = descargarArchivo;
window.enviarPQR = enviarPQR;
window.editarPerfil = editarPerfil;
window.publicar = publicar;